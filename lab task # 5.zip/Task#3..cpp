#include<stdio.h>
int main()
{
	int X,Y,Z,W;
	printf("Enter value of X\n");
	scanf("%d",&X);
	printf("Enter value of Y\n");
	scanf("%d",&Y);
	printf("Enter value of Z\n");
	scanf("%d",&Z);
	printf("Enter value of W\n");
	scanf("%d",&W);
	if(X>Y)
	{
		if(X>Z)
		{
			if(X>W)
			{
				printf("X IS THE GREATES: %d \n",X);
			}
			else
			{
				printf("W IS THE GREATEST: %d\n",W);
			}
		}
		else if (Z>W)
		{
			printf("Z IS THE GREATEST: %d\n",Z);
		}
		else
		{
			printf("W IS THE GREATEST: %d \n",W);
		}
		
	}
	else if(Y>Z)
	{
		if(Y>W)
		{
			printf("Y IS THE GREATEST: %d \n",Y);
		}
		else
		{
			printf("W IS THE GREATEST: %d \n",W);
		}
	}
	else if (Z>W)
	{
		printf("Z IS THE GREATEST: %d \n",Z);
	}
	else
	{
		printf("W IS THE GREATEST: %d\n",W);
	}
	return 0;
	
}
	
