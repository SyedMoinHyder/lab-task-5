#include<stdio.h>
int main()
{
	int s1,s2,s3;
	printf("enter s1:\n");
	scanf("%d",&s1);
	printf("enter s2:\n");
	scanf("%d",&s2);
	printf("enter s3:\n");
	scanf("%d",&s3);
	if (s1+s2>s3&&s1+s3>s2&&s2+s3>s1)
	{
		if(s1==s2&&s2==s3)
		{
			printf("IT IS EQUILETRAL TRIANGLE\n");
		}
		else if(s1==s2&&s2!=s3||s1==s3&&s1!=s2||s2==s3&&s3!=s1)
		{
			printf("IT IS ISOSCALES TRIANGLE\n");
		}
		else if(s1!=s2&&s2!=s3||s2!=s3&&s2!=s1||s3!=s1&&s1!=s2)
		{
			printf("IT IS SCALEN TRIANGLE:\n");
		}
		
	}
	else
	{
		printf("IT IS NOT A TRIANGLE \n");
	}
	return 0;
}
