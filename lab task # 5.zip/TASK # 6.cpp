#include<stdio.h>
#include<math.h>
int main()
{
	int mode;
	char op;
	int num1;
	int num2;
	int result;
	double root;
	printf("Enter 1 for mode 1\n");
	printf("Enter 2 for mode 2\n");
	scanf("%d",&mode);
	switch(mode)
	{
		case 1:
			{
			   printf("Enter operation you want\n");
			   printf("+\n");	
	           printf("-\n");	
			   printf("*\n");	
			   printf("/\n");
			   scanf(" %c",&op);
			   switch(op)
			   {
			   	case '+':
			   		{
			   			printf("Enter your num 1 \n");
			   			scanf("%d",&num1);
			   			printf("Enter your num 2 \n");
			   			scanf("%d",&num2);
			   			result=num1+num2;
			   			printf("Enter result %d\n",result);
			   			break;
					   }
				case '-':
					{
					    printf("Enter your num 1 \n");
			   			scanf("%d",&num1);
			   			printf("Enter your num 2 \n");
			   			scanf("%d",&num2);
			   			result=num1-num2;
			   			printf("Enter result %d\n",result);
			   			break;	
					}
				case '*':
			    	{
					    printf("Enter your num 1 \n");
			   			scanf("%d",&num1);
			   			printf("Enter your num 2 \n");
			   			scanf("%d",&num2);
			   			result=num1*num2;
			   			printf("Enter result %d\n",result);
			   			break;
				    }
				case '/':
				    {
				    	printf("Enter your num 1 \n");
			   			scanf("%d",&num1);
			   			printf("Enter your num 2 \n");
			   			scanf("%d",&num2);
			   			result=num1/num2;
			   			printf("Enter result %d\n",result);
			   			break;
					}
				default:
					{
						printf("Not define in these funtion");
						break;
					}
			   }
			   break;
		    	}
		case 2:
			{
				printf("Enter your advance opreation:\n");
				printf("enter s for square\n");
				printf("enter r for square root \n");
				scanf(" %c",&op);
				switch(op)
				{
					case 's':
						{
						printf("Enter your num 1 \n");
			   			scanf("%d",&num1);
		                result=num1*num1;
			   			printf("Enter SQUARE IS  %d\n",result);
			   			break;
						}
						case 'r':
							{
							printf("Enter your num 1 \n");
			   			    scanf("%d",&num1);
			   			    if(num1<0)
			   			    {
			   			    	printf("Error");
							   }
							   else
							   {
							   	root=sqrt(num1);
							   	printf("Square root is= %.2f \n",root);
							   }
			    			break;
							}
				}
				break;
			}
	}
	return 0;
}
