#include<stdio.h>
int main()
{
	int choice;
	int price;
	int slection;
    printf("Enter 1 for beverages  \n");
    printf("Enter 2 for Main course\n");
    printf("Enter 3 for Deserts    \n");
    scanf("%d",&choice);
    switch(choice)
    {
    	case 1:
    		{
    			printf("Enter 1 for juice\n");
    			printf("Enter 2 for shake\n");
    			printf("Enter 3 for drink\n");\
    			scanf("%d",&slection);
    			switch(slection)
    			{
    				case 1:
    					{
    						price=300;
    						break;
						}
					case 2:
    					{
    						price=450;
    						break;
						}
			        case 3:
    					{
    						price=100;
    						break;
						}
					default:
						{
							printf("please sleact appropriate choice");
							break;
					   }
					
		    	}
		    	break;
			}
			case 2:
    		{
    			printf("Enter 1 for briyani\n");
    			printf("Enter 2 for burger\n");
    			printf("Enter 3 for pizza\n");\
    			scanf("%d",&slection);
    			switch(slection)
    			{
    				case 1:
    					{
    						price=550;
    						break;
						}
					case 2:
    					{
    						price=450;
    						break;
						}
			        case 3:
    					{
    						price=1100;
    						break;
						}
					default:
						{
							printf("please sleact appropriate choice");
							break;
						}
		    	}
		    	break;
			}
				case 3:
    		{
    			printf("Enter 1 for ice creame\n");
    			printf("Enter 2 for custerd   \n");
    			printf("Enter 3 for almod     \n");\
    			scanf("%d",&slection);
    			switch(slection)
    			{
    				case 1:
    					{
    						price=390;
    						break;
						}
					case 2:
    					{
    						price=410;
    						break;
						}
			        case 3:
    					{
    						price=10;
    						break;
						}
					default:
						{
							printf("please sleact appropriate choice");
							break;
					}
		    	}
		    	break;
			}
	}
	printf("Here is your Final Bill=%d$",price);
	return 0;
	
}
