#include <stdio.h>

int main() {
    char accType, trans;

    printf("===== ATM MENU =====\n");
    printf("Select Account Type:\n");
    printf("1. Savings\n");
    printf("2. Current\n");
    printf("Enter choice: ");
    scanf(" %c", &accType);

    switch (accType) {
        case '1':
            printf("\n--- Savings Account ---\n");
            printf("1. Deposit\n");
            printf("2. Withdraw\n");
            printf("3. Check Balance\n");
            printf("Enter transaction: ");
            scanf(" %c", &trans);

            switch (trans) {
                case '1':
                    printf("Savings Account: Amount deposited successfully.\n");
                    break;
                case '2':
                    printf("Savings Account: Amount withdrawn successfully.\n");
                    break;
                case '3':
                    printf("Savings Account: Displaying your current balance.\n");
                    break;
                default:
                    printf("Invalid transaction choice!\n");
            }
            break;

        case '2':
            printf("\n--- Current Account ---\n");
            printf("1. Deposit\n");
            printf("2. Withdraw\n");
            printf("3. Check Balance\n");
            printf("Enter transaction: ");
            scanf(" %c", &trans);

            switch (trans) {
                case '1':
                    printf("Current Account: Amount deposited successfully.\n");
                    break;
                case '2':
                    printf("Current Account: Amount withdrawn successfully (overdraft rules may apply).\n");
                    break;
                case '3':
                    printf("Current Account: Displaying your current balance.\n");
                    break;
                default:
                    printf("Invalid transaction choice!\n");
            }
            break;

        default:
            printf("Invalid account type!\n");
    }

    return 0;
}
