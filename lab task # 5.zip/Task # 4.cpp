#include<stdio.h>
int main()
{
	char ct;
	int bill;
	int units;
	int rate;
	printf("enter your connection type\n");
	printf("Enter D for Domestic  \n");
	printf("Enter C for Commercial\n");
	scanf(" %c",&ct);
	printf("Enter units you consumed\n");
	scanf("%d",&units);
	if(ct=='c'||ct=='C')
	{
		if(units>0&&units<=100)
		{
			rate=10;
		}
		else if(units>=101&&units<=300)
		{
			rate=40;
		}
			else if(units>300)
		{
			rate=70;
		}
	}
	else if (ct=='d'||ct=='D')
	{
	if(units>0&&units<=100)
		{
			rate=50;
		}
		else if(units>=101&&units<=300)
		{
			rate=90;
		}
			else if(units>300)
		{
			rate=100;
		}
   }
	bill=rate*units;
	printf("YOUR TOTAL BILL IS=%d$",bill);
}
