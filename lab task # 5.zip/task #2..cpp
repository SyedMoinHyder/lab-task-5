#include<stdio.h>
int main()
{
	int age;
	int price;
	char day;
	printf("* Welcome to Cinema Ticket Counter*\n");
	printf("Enter your price:\n");
	scanf("%d",&price);
	printf("Enter your age:\n");
	scanf("%d",&age);
	printf("Enter your day:\n");
	printf("Enter H for Holiday/weekend\n");
	printf("Enter W for weekday\n");
	scanf(" %c",&day);
	if(age<=12||age>=60)
	{
		
		price=price-(price*0.10);
		if(day=='H'||'h')
		{
			price=price-(price*0.30);
		}
	}
	else if (day=='H'||day=='h')
	{
		price=price-(price*0.30);
	}
	printf("Your price is =%d$",price);
	return 0;
}
