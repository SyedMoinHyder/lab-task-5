#include<stdio.h>
int main()
{
	char dp;
	int semester;
	printf("Select department to know about core courses\n");
	printf("select C for BS   computer  science \n");
	printf("select E for Electrical  enjineering\n");
	printf("select B for Buisness administration\n");
	scanf(" %c",&dp);
	switch(dp)
	{
		case 'C':
			{
				printf("Select Semester\n");
				printf("select 1 for first semester\n");
				printf("select 2 for first semester\n");
				printf("select 3 for first semester\n");
				scanf("%d",&semester);
				switch(semester)
				{
					case 1:
						{
						  printf("Core course is programming fundamentals");
						  break;
						}
					case 2:
					    	{
						  printf("Core course is object oriented programing");
						  break;
						}
					case 3:
							{
						  printf("Core course is Data Structure");
						  break;
						}
							default:
					{
						printf("invalid input");
						break;
					}
				}
				break;
			}
		case 'E':
			{
				printf("Select Semester\n");
				printf("select 1 for first semester\n");
				printf("select 2 for first semester\n");
				printf("select 3 for first semester\n");
				scanf("%d",&semester);
				switch(semester)
				{
					case 1:
						{
						  printf("Core course is enjinnering drawing");
						  break;
						}
					case 2:
					    	{
						  printf("Core course is line circuit anaylisis");
						  break;
						}
					case 3:
							{
						  printf("Core course is electrical anaylisis circuit");
						  break;
						}
					default:
					{
						printf("invalid input");
						break;
					}
				}
				break;
			}
			case 'B':
				{
				printf("Select Semester\n");
				printf("select 1 for first semester\n");
				printf("select 2 for first semester\n");
				printf("select 3 for first semester\n");
				scanf("%d",&semester);
				switch(semester)
				{
					case 1:
						{
						  printf("Core course is managment science");
						  break;
						}
					case 2:
					    	{
						  printf("Core course is accounting finance");
						  break;
						}
					case 3:
							{
						  printf("Core course is buisnes anaylatics");
						  break;
						}
					default:
					{
						printf("invalid input");
						break;
					}
				}
				break;
			}
			default:
				{
					printf("invalid input");
					break;
				}
	}
	return 0;
}
