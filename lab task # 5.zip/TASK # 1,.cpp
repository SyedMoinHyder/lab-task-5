//TASK # 1
#include<stdio.h>
int main()
{
	int marks;
	printf("Enter you marks:\n");
	scanf("%d",&marks);
	if(marks>100)
	{
		printf("Error");
	}
	else if(marks>=90)
	{
		if(marks==100)
		{
			printf("Perfect!");
		}
		else
		{
			printf("Grade A");
		}
	}
	else if(marks>=75)
	{
		printf("Grade B");
	}
	else if(marks>=60)
	{
		printf("Grade C");
	}
	else if(marks>=40)
	{
		printf("Grade D");
	}
		else if(marks>=0)
	{
		printf("Grade F");
	}
	return 0;
}
